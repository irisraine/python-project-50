from gendiff.helpers.stringify import stringify

__all__ = [stringify]
